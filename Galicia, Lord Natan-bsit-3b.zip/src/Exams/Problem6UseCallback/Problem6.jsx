import { useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState(null);

 
  const onDelete = (vin) => {
    const updatedCars = cars.filter(car => car.vin !== vin);
    setCars(updatedCars);
  };

  const onEdit = (car) => {
    setSelected(car); 
  };

 
  const onSave = () => {
    if (!selected) return;

    const updatedCars = cars.map(car => {
      if (car.vin === selected.vin) {
        return selected;  
      }
      return car;
    });
    setCars(updatedCars);
    setSelected(null);  
  };

  
  const onClear = () => {
    setSelected(null);
  };

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setSelected((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            name='vin'
            value={selected ? selected.vin : ''}
            disabled
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            name='make'
            value={selected ? selected.make : ''}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            name='model'
            value={selected ? selected.model : ''}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            name='year'
            value={selected ? selected.year : ''}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            name='color'
            value={selected ? selected.color : ''}
            onChange={handleChange}
          />
        </div>
        <button type='button' onClick={onSave} disabled={!selected}>Save</button>
        <button type='button' onClick={onClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type='button' onClick={() => onEdit(car)}>Edit</button>
                  <button type='button' onClick={() => onDelete(car.vin)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}