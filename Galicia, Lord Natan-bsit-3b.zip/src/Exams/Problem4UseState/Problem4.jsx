import { useState } from "react";

export default function Problem4() {
  // State to store form data
  const [name, setName] = useState('');
  const [yearLevel, setYearLevel] = useState('');
  const [course, setCourse] = useState('');
  const [submittedData, setSubmittedData] = useState(null); // State to store the object after submission

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the page from refreshing on form submit
    
    // Store the form data as an object
    setSubmittedData({
      name,
      yearLevel,
      course
    });
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'block' }}>
          Name: 
          <input 
            type="text" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
          />
        </div>
        
        <div style={{ display: 'block' }}>
          <p>Year Level:</p>
          <input
            type="radio"
            id="firstYear"
            name="yearlevel"
            value="First Year"
            checked={yearLevel === 'First Year'}
            onChange={() => setYearLevel('First Year')}
          />
          <label htmlFor="firstYear">First Year</label>
          <br />
          
          <input
            type="radio"
            id="secondYear"
            name="yearlevel"
            value="Second Year"
            checked={yearLevel === 'Second Year'}
            onChange={() => setYearLevel('Second Year')}
          />
          <label htmlFor="secondYear">Second Year</label>
          <br />
          
          <input
            type="radio"
            id="thirdYear"
            name="yearlevel"
            value="Third Year"
            checked={yearLevel === 'Third Year'}
            onChange={() => setYearLevel('Third Year')}
          />
          <label htmlFor="thirdYear">Third Year</label>
          <br />
          
          <input
            type="radio"
            id="fourthYear"
            name="yearlevel"
            value="Fourth Year"
            checked={yearLevel === 'Fourth Year'}
            onChange={() => setYearLevel('Fourth Year')}
          />
          <label htmlFor="fourthYear">Fourth Year</label>
          <br />
          
          <input
            type="radio"
            id="fifthYear"
            name="yearlevel"
            value="Fifth Year"
            checked={yearLevel === 'Fifth Year'}
            onChange={() => setYearLevel('Fifth Year')}
          />
          <label htmlFor="fifthYear">Fifth Year</label>
          <br />
          
          <input
            type="radio"
            id="irregular"
            name="yearlevel"
            value="Irregular"
            checked={yearLevel === 'Irregular'}
            onChange={() => setYearLevel('Irregular')}
          />
          <label htmlFor="irregular">Irregular</label>
          <br />
        </div>

        <div style={{ display: 'block' }}>
          Course:
          <select 
            value={course} 
            onChange={(e) => setCourse(e.target.value)}
          >
            <option value="BSCS">BSCS</option>
            <option value="BSIT">BSIT</option>
            <option value="BSCpE">BSCpE</option>
            <option value="ACT">ACT</option>
          </select>
        </div>

        <div>
          <button type="submit">Submit</button>
        </div>
      </form>

    
      {submittedData && (
        <div style={{ marginTop: '20px' }}>
          <h3>Form Data Submitted:</h3>
          <pre>{JSON.stringify(submittedData, null, 2)}</pre>
        </div>
      )}
    </>
  );
}
