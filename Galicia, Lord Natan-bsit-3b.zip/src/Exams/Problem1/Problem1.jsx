import React from 'react';

const Problem1 = ({ name, course, section }) => {
  return (
    <div>
      <h1>Student Information</h1>
      <p><strong>Name: Joshua D.S. Zapata</strong></p>
      <p><strong>Course: Information Technology </strong> </p>
      <p><strong>Section: BSIT-3B</strong> </p>
    </div>
  );
};

export default Problem1;